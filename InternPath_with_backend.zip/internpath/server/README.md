# InternPath — Backend API

A small Express + SQLite API that replaces InternPath's fake, client-side
login/register with real accounts: hashed passwords, a proper database, and
JWT-based authentication.

## What this replaces

Previously, `index.html` stored users in a plain in-memory JS array
(`_store.users`) with passwords run through `btoa()` — that's base64 encoding,
**not** encryption or hashing, and it was trivial to read in the browser
console. Nothing persisted between page reloads.

This backend stores users in a real SQLite database, hashes passwords with
bcrypt, and issues JWTs so the frontend can prove who's logged in on each
request.

## Setup

```bash
cd server
npm install
cp .env.example .env
```

Open `.env` and set a real `JWT_SECRET`. Generate one with:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Then start the server:

```bash
npm start
```

You should see:

```
✅ InternPath API listening on http://localhost:4000
```

A SQLite file will be created automatically at `./data/internpath.db` (path is
configurable via `DB_PATH` in `.env`).

## Endpoints

| Method | Path                | Auth required | Description                        |
|--------|---------------------|----------------|------------------------------------|
| GET    | `/api/health`        | no             | Health check                       |
| POST   | `/api/auth/register`  | no             | Create an account, returns a JWT   |
| POST   | `/api/auth/login`     | no             | Log in, returns a JWT              |
| GET    | `/api/auth/me`        | yes            | Get the current user's profile     |
| POST   | `/api/auth/logout`    | yes            | No-op today (JWTs are stateless)   |

Protected routes expect:

```
Authorization: Bearer <token>
```

### Example requests

```bash
curl -X POST http://localhost:4000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Ada","lastName":"Lovelace","email":"ada@example.com","password":"secret123"}'

curl -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ada@example.com","password":"secret123"}'

curl http://localhost:4000/api/auth/me \
  -H "Authorization: Bearer <token from login/register>"
```

## Security notes

- Passwords are hashed with **bcrypt** (12 salt rounds) — never stored or
  returned in plain text.
- `/register` and `/login` are rate-limited (15 requests / 15 min / IP) to
  slow down brute-force attempts.
- Login errors are intentionally generic (`Invalid email or password.`) so an
  attacker can't tell whether an email is registered.
- The JWT secret lives only in `.env`, which is git-ignored — never commit it.
- CORS is locked to the origins listed in `CORS_ORIGIN`; add your deployed
  frontend's URL there when you go live.

## ⚠️ About the Anthropic API key

The frontend currently keeps your Anthropic API key in `localStorage` and
calls `api.anthropic.com` directly from the browser. That means **anyone who
opens dev tools on your site can read and steal your key** and rack up usage
on your account.

The right fix is to add an endpoint here, e.g. `POST /api/ai/complete`, that:
1. Requires a valid JWT (so only your logged-in users can use it),
2. Holds the real Anthropic API key server-side in `.env`,
3. Forwards the prompt to Anthropic and returns the response.

That's a natural next step once this auth backend is in place — happy to add
it if you want the AI calls proxied through the server instead of exposed in
the browser.

## Project structure

```
server/
├── server.js              Express app entrypoint
├── db/
│   └── init.js             SQLite connection + schema setup
├── middleware/
│   └── auth.js              JWT verification middleware
├── routes/
│   └── auth.js               /register, /login, /me, /logout
├── .env.example
├── .env                     (you create this — never commit it)
└── package.json
```
