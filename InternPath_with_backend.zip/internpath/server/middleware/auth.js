const jwt = require('jsonwebtoken');

/**
 * Reads "Authorization: Bearer <token>", verifies it, and attaches
 * the decoded payload (userId, email) to req.user.
 * Responds 401 if the header is missing/malformed or the token is invalid/expired.
 */
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ error: 'Missing or malformed Authorization header.' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = { id: payload.sub, email: payload.email };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
}

module.exports = { requireAuth };
