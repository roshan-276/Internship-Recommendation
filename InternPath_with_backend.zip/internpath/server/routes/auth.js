const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');

const db = require('../db/init');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const SALT_ROUNDS = 12;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// ------------------------------------------------------------------
// Rate limiting — slows down brute-force login/register attempts.
// 15 requests per 15 minutes per IP on these two sensitive endpoints.
// ------------------------------------------------------------------
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again later.' },
});

// Prepared statements
const findUserByEmail = db.prepare('SELECT * FROM users WHERE email = ?');
const findUserById = db.prepare('SELECT * FROM users WHERE id = ?');
const insertUser = db.prepare(`
  INSERT INTO users (first_name, last_name, email, password_hash)
  VALUES (@first_name, @last_name, @email, @password_hash)
`);

function signToken(user) {
  return jwt.sign(
    { sub: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

// Never send the password hash back to the client.
function toPublicUser(user) {
  return {
    id: user.id,
    firstName: user.first_name,
    lastName: user.last_name,
    email: user.email,
    name: [user.first_name, user.last_name].filter(Boolean).join(' '),
    createdAt: user.created_at,
  };
}

// ------------------------------------------------------------------
// POST /api/auth/register
// ------------------------------------------------------------------
router.post('/register', authLimiter, async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body || {};

    if (!firstName || !email || !password) {
      return res.status(400).json({ error: 'Please fill all required fields.' });
    }
    if (typeof email !== 'string' || !EMAIL_RE.test(email.trim())) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    if (typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const normalizedEmail = email.trim().toLowerCase();

    if (findUserByEmail.get(normalizedEmail)) {
      return res.status(409).json({ error: 'Email already registered.' });
    }

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    const info = insertUser.run({
      first_name: firstName.trim(),
      last_name: (lastName || '').trim(),
      email: normalizedEmail,
      password_hash: passwordHash,
    });

    const user = findUserById.get(info.lastInsertRowid);
    const token = signToken(user);

    res.status(201).json({ token, user: toPublicUser(user) });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// ------------------------------------------------------------------
// POST /api/auth/login
// ------------------------------------------------------------------
router.post('/login', authLimiter, async (req, res) => {
  try {
    const { email, password } = req.body || {};

    if (!email || !password) {
      return res.status(400).json({ error: 'Invalid email or password.' });
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const user = findUserByEmail.get(normalizedEmail);

    // Deliberately generic error — don't reveal whether the email exists.
    const genericError = () => res.status(401).json({ error: 'Invalid email or password.' });

    if (!user) return genericError();

    const passwordOk = await bcrypt.compare(password, user.password_hash);
    if (!passwordOk) return genericError();

    const token = signToken(user);
    res.json({ token, user: toPublicUser(user) });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// ------------------------------------------------------------------
// GET /api/auth/me  (protected)
// ------------------------------------------------------------------
router.get('/me', requireAuth, (req, res) => {
  const user = findUserById.get(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: toPublicUser(user) });
});

// ------------------------------------------------------------------
// POST /api/auth/logout
// JWTs are stateless, so there's nothing to invalidate server-side yet.
// This endpoint exists so the frontend has a consistent call to make,
// and so a token-blocklist or refresh-token flow can be added later
// without changing the frontend contract.
// ------------------------------------------------------------------
router.post('/logout', requireAuth, (req, res) => {
  res.json({ ok: true });
});

module.exports = router;
