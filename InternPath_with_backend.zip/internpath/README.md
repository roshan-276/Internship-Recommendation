# InternPath – AI Career Platform

An AI-powered career platform with resume analysis, builder, internship recommendations, career mentor chatbot, and job matching.

## 🚀 Quick Start

### Prerequisites
- [VS Code](https://code.visualstudio.com/)
- [Live Server Extension](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) by Ritwick Dey

### Steps

1. **Start the backend** (handles login/register — see `server/README.md` for details)
   ```bash
   cd server
   npm install
   cp .env.example .env
   # open .env and set a real JWT_SECRET (instructions are inside the file)
   npm start
   ```
   You should see `✅ InternPath API listening on http://localhost:4000`. Leave this running.

2. **Open the project folder in VS Code**
   ```
   File → Open Folder → Select the InternPath folder
   ```

3. **Install Live Server** (if not already installed)
   - Press `Ctrl+Shift+X`
   - Search "Live Server" → Install

4. **Run the frontend**
   - Right-click `index.html` → **Open with Live Server**
   - App opens at: `http://localhost:3000`
   - Register a new account — it's now created via the backend from step 1,
     with the password properly hashed and stored in a real SQLite database
     (previously this was faked in browser memory).

5. **Add your Anthropic API Key** (for the AI features — separate from login)
   - Once logged in, use the in-app API key modal to paste your key.
   - It's saved to your browser's `localStorage` only. See the security note
     below — this key is visible in your browser and should not be used in a
     shared or public deployment as-is.

## 🔑 Get API Key
- Visit: https://console.anthropic.com/
- Sign up / Log in → API Keys → Create Key

## 📦 Features
- ✅ Login / Register – real accounts via the Express + SQLite backend (hashed passwords, JWT auth)
- 📄 Resume Analyzer – ATS score, strengths, skill gaps
- 🔧 Resume Builder – Live preview, themes, PDF download
- 🎓 Internship Recommendations – AI-matched internships based on your skills
- 🤖 AI Career Mentor – Chatbot with resume context
- 💼 Job Matches – AI-matched jobs with LinkedIn links

## 🗂 Project Structure
```
InternPath/
├── index.html        ← Frontend: entire application (HTML + CSS + JS)
├── README.md         ← This file
├── server/           ← Backend: Express + SQLite auth API (see server/README.md)
│   ├── server.js
│   ├── db/
│   ├── middleware/
│   └── routes/
└── .vscode/
    └── settings.json ← Live Server config (port 3000)
```

## ⚠️ Notes
- User accounts (name, email, hashed password) are stored in a real SQLite
  database by the backend in `/server` — not in browser localStorage anymore.
- The backend must be running (`npm start` in `/server`) for login/register to work.
- Your Anthropic API key is still entered client-side and kept in
  `localStorage` for the AI features — this is fine for local/personal use,
  but anyone with browser dev tools access on a shared deployment could read
  it. See `server/README.md` for how to proxy AI calls through the backend
  instead if you deploy this publicly.
- Requires internet connection for AI features (Anthropic API).
